WardConnect web prototype.
Publish index.html on a static HTTPS host. Then use the public URL to make the final QR code.
This prototype stores demo data in the browser; a real deployment needs a secure backend/database.
